/**
 * Public Class: Student
 * Date last modified: 10/3/2017
 */

public class Main {
    public static void main(String[] args) {
        GradTA ta = new GradTA();
        ta.print();
    }
}
